const express = require('express');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const mysql = require('mysql2');
const cors = require('cors');
const session = require('express-session');
const methodOverride = require('method-override');

// Configuration du serveur
const app = express();
const port = 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use(methodOverride('_method'));


app.set('view engine', 'ejs');
app.set('views', 'views');

app.use(session({
    secret: 'code_secret',
    resave: false,
    saveUninitialized: true
  }));

// Connexion à la BDD
const db = mysql.createConnection({
  host: 'localhost',
  // si besoin, remplacez ces données par celle de votre BDD
  user: 'root',
  password: '', 
  database: 'e_commerce',
});

// Vérifie la connexion
db.connect((err) => {
  if (err) throw err;
  console.log('Connecté à la base de données MySQL.');
});

app.get('/profil', (req, res) => {
    const id_utilisateur = req.session.userId;

    if (!id_utilisateur) {
      return res.status(401).send('Utilisateur non authentifié');
    }

    const query = 'SELECT * FROM Utilisateur WHERE id_utilisateur = ?';
    db.query(query, [id_utilisateur], (err, results) => {
      if (err) {
        return res.status(500).send('Erreur lors de la récupération des informations.');
      }

      const user = results[0];
      res.render('profil', { user });
    });
});



app.post('/register', (req, res) => {
    const { nom, prenom, email, password, adresse, telephone } = req.body;

    const checkUserQuery = 'SELECT * FROM Utilisateur WHERE email = ?';
    db.query(checkUserQuery, [email], (err, results) => {
        if (err) throw err;

        if (results.length > 0) {
        res.status(400).send('Cet utilisateur existe déjà.');
        } else {
        bcrypt.hash(password, 10, (err, hash) => {
            if (err) throw err;

            const insertQuery = `
            INSERT INTO Utilisateur (nom, prenom, email, mot_de_passe, adresse, telephone)
            VALUES (?, ?, ?, ?, ?, ?)
            `;

            db.query(
            insertQuery,
            [nom, prenom, email, hash, adresse || '', telephone || ''],
            (err, result) => {
                if (err) {
                res.status(500).send('Erreur lors de l inscription.');
                throw err;
                }
                res.send('Utilisateur enregistré avec succès !');
            }
            );
        });
        }
    });
    });
  

app.post('/login', (req, res) => {
  const { email, password } = req.body;

  const sql = 'SELECT * FROM Utilisateur WHERE email = ?';
  db.query(sql, [email], (err, results) => {
    if (err) throw err;

    if (results.length > 0) {
      const user = results[0];

      bcrypt.compare(password, user.mot_de_passe, (err, isMatch) => {
        if (err) throw err;

        if (isMatch) {
            req.session.userId = user.id_utilisateur;
            res.redirect('/profil');
        } else {
          res.send('<h1>Mot de passe incorrect.</h1>');
        }
      });
    } else {
      res.send('<h1>Utilisateur introuvable.</h1>');
    }
  });
});

app.put('/updateUser', (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: 'Vous devez être connecté pour modifier votre profil.' });
    }
  
    const { id_utilisateur, nom, prenom, email, adresse, telephone } = req.body;
  
    const checkUserQuery = 'SELECT * FROM Utilisateur WHERE id_utilisateur = ?';
    db.query(checkUserQuery, [id_utilisateur], (err, results) => {
      if (err) {
        return res.status(500).json({ message: 'Erreur lors de la vérification de l\'utilisateur.' });
      }
  
      if (results.length === 0) {
        return res.status(404).json({ message: 'Utilisateur introuvable.' });
      } else {
        const updateQuery = 'UPDATE Utilisateur SET nom = ?, prenom = ?, email = ?, adresse = ?, telephone = ? WHERE id_utilisateur = ?';
        db.query(updateQuery, [nom, prenom, email, adresse, telephone, id_utilisateur], (err, result) => {
          if (err) {
            return res.status(500).json({ message: 'Erreur lors de la mise à jour des informations.' });
          }
          res.json({ message: 'Informations de l\'utilisateur mises à jour avec succès.' });
        });
      }
    });
  });
  
  
    app.get('/produits', (req, res) => {
        const sql = 'SELECT * FROM produit';
        db.query(sql, (err, results) => {
        if (err) {
            console.error('Erreur SQL :', err);
            res.status(500).send('Erreur lors de la récupération des produits.');
            return;
        }
        res.json(results);
        });
    });


  app.get('/produits/:id', (req, res) => {
    const { id } = req.params;
    const sql = 'SELECT * FROM produit WHERE id_produit = ?';
    db.query(sql, [id], (err, result) => {
      if (err) {
        res.status(500).send('Erreur lors de la récupération du produit.');
        throw err;
      }
      if (result.length === 0) {
        res.status(404).send('Produit non trouvé.');
      } else {
        res.json(result[0]);
      }
    });
  });
  
    app.post('/produits', (req, res) => {
        const { nom, description, prix, quantite_disponible, categorie_id } = req.body;
    
        if (!nom || !description || !prix || !quantite_disponible || !categorie_id) {
            return res.status(400).json({ message: 'Tous les champs sont requis.' });
        }
    
        const query = `
            INSERT INTO produit (nom, description, prix, quantite_disponible, categorie_id)
            VALUES (?, ?, ?, ?, ?)
        `;
    
        db.query(query, [nom, description, prix, quantite_disponible, categorie_id], (err, result) => {
            if (err) {
                console.error('Erreur lors de l\'insertion :', err);
                return res.status(500).json({ message: 'Erreur lors de l\'ajout du produit.' });
            }
            res.status(201).json({ message: 'Produit ajouté avec succès !', id_produit: result.insertId });
        });
    });


  app.put('/produits', (req, res) => {
    const { id_produit, nom, description, prix, quantite_disponible } = req.body;
    const updateSql = `
      UPDATE produit
      SET nom = ?, description = ?, prix = ?, quantite_disponible = ?
      WHERE id_produit = ?
    `;
    db.query(updateSql, [nom, description, prix, quantite_disponible, id_produit], (err, result) => {
      if (err) {
        res.status(500).send('Erreur lors de la mise à jour du produit.');
        throw err;
      }
      res.send('Produit mis à jour avec succès.');
    });
  });
  

  app.delete('/produits/:id', (req, res) => {
    const { id } = req.params;
    
    const sqlDeleteAvis = 'DELETE FROM avis WHERE id_produit = ?';
    db.query(sqlDeleteAvis, [id], (err, result) => {
        if (err) {
            console.error('Erreur lors de la suppression des avis:', err);
            return res.status(500).send('Erreur lors de la suppression des avis.');
        }

        const sqlDeleteProduit = 'DELETE FROM produit WHERE id_produit = ?';
        db.query(sqlDeleteProduit, [id], (err, result) => {
            if (err) {
                console.error('Erreur lors de la suppression du produit:', err);
                return res.status(500).send('Erreur lors de la suppression du produit.');
            }
            return res.status(200).send('Produit et ses avis supprimés avec succès.');
        });
    });
});


app.listen(port, () => {
  console.log(`Serveur démarré sur http://localhost:${port}`);
});
